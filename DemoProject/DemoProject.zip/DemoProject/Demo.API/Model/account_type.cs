﻿namespace Demo.API.Model
{
    public class account_type
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
